---
name: MediCare Chroma
colors:
  surface: '#f8f9fa'
  surface-dim: '#d9dadb'
  surface-bright: '#f8f9fa'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f4f5'
  surface-container: '#edeeef'
  surface-container-high: '#e7e8e9'
  surface-container-highest: '#e1e3e4'
  on-surface: '#191c1d'
  on-surface-variant: '#3d4a3e'
  inverse-surface: '#2e3132'
  inverse-on-surface: '#f0f1f2'
  outline: '#6c7b6d'
  outline-variant: '#bbcbbb'
  surface-tint: '#006d37'
  primary: '#006d37'
  on-primary: '#ffffff'
  primary-container: '#2ecc71'
  on-primary-container: '#005027'
  inverse-primary: '#4ae183'
  secondary: '#006397'
  on-secondary: '#ffffff'
  secondary-container: '#5cb8fd'
  on-secondary-container: '#00476e'
  tertiary: '#83439e'
  on-tertiary: '#ffffff'
  tertiary-container: '#df98fa'
  on-tertiary-container: '#672782'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#6bfe9c'
  primary-fixed-dim: '#4ae183'
  on-primary-fixed: '#00210c'
  on-primary-fixed-variant: '#005228'
  secondary-fixed: '#cce5ff'
  secondary-fixed-dim: '#92ccff'
  on-secondary-fixed: '#001d31'
  on-secondary-fixed-variant: '#004b73'
  tertiary-fixed: '#f8d8ff'
  tertiary-fixed-dim: '#ebb2ff'
  on-tertiary-fixed: '#320047'
  on-tertiary-fixed-variant: '#692984'
  background: '#f8f9fa'
  on-background: '#191c1d'
  surface-variant: '#e1e3e4'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 24px
  lg: 40px
  xl: 64px
  gutter: 24px
  margin: 32px
---

## Brand & Style
The design system is engineered for the high-stakes environment of modern healthcare, prioritizing clarity, precision, and trust. The visual narrative balances clinical authority with a refreshing, contemporary energy that moves away from traditional, sterile medical interfaces.

The design style is **Corporate / Modern** with a lean toward **High-Contrast / Bold** for critical information pathways. It utilizes high-fidelity surfaces, crisp data visualizations, and a rigorous adherence to hierarchy to ensure that practitioners can make informed decisions under pressure. The emotional response is one of reliability and "calm urgency"—clean enough to feel sterile, yet vibrant enough to feel technologically advanced.

## Colors
The palette is rooted in a functional color theory specific to healthcare informatics:

- **Vital Green (#2ECC71):** The primary driver for "Go" states, healthy metrics, and primary calls to action. It represents recovery and stability.
- **Clinical Blue (#3498DB):** Used for informational components, navigation, and secondary actions. It provides a grounding, professional contrast to the green.
- **Bio Purple (#9B59B6):** Reserved for specialized data sets, laboratory results, or premium features within the application.
- **Clean Care (#F8F9FA):** The foundation. This high-brightness neutral ensures a glare-free, sterile-looking canvas that mimics a modern clinical environment.
- **Emergency Red (#E74C3C):** High-visibility accent color used strictly for critical alerts, physiological alarms, and destructive actions.
- **Medical Dark (#2C3E50):** A deep, saturated navy-grey for typography and structural lines, offering better readability and less eye strain than pure black.

## Typography
This design system utilizes **Plus Jakarta Sans** across all levels. The typeface was chosen for its modern, geometric construction and high x-height, which ensures exceptional legibility in data-dense medical charts.

- **Headlines:** Bold and tight. Use `-0.01em` to `-0.02em` letter spacing on larger sizes to maintain a sleek, professional look.
- **Body Text:** Standard weight (400) for all patient records and documentation. Line heights are generous (1.5x) to prevent "line-skipping" when reading long-form clinical notes.
- **Labels:** Use the `label-md` role for table headers and metadata descriptors to provide a clear structural contrast to dynamic data.

## Layout & Spacing
The layout follows a **Fluid Grid** system based on an 8px spatial rhythm. This ensures that the interface scales gracefully from diagnostic tablets to desktop nursing stations.

- **Desktop (1440px+):** 12-column grid, 24px gutters, 32px side margins.
- **Tablet (768px - 1439px):** 8-column grid, 16px gutters, 24px side margins.
- **Mobile (< 767px):** 4-column grid, 16px gutters, 16px side margins.

Use `lg` (40px) and `xl` (64px) spacing for vertical section separation to allow the "Clean Care" background to create breathing room between complex data sets.

## Elevation & Depth
Depth in this design system is created through **Tonal Layers** and **Low-Contrast Outlines**. We avoid heavy shadows to maintain the "clinical" and "flat" aesthetic, which reduces visual noise.

- **Level 0 (Surface):** Clean Care (#F8F9FA). Used for the main background.
- **Level 1 (Cards/Containers):** White (#FFFFFF) with a 1px solid border in Medical Dark at 8% opacity. This creates a subtle lift without using shadows.
- **Level 2 (Interactive/Floating):** White (#FFFFFF) with a very soft, diffused shadow: `0px 4px 12px rgba(44, 62, 80, 0.08)`. Use this for dropdowns and active modals.
- **Backdrop Blur:** Use a 12px blur for modal overlays to keep the clinical context visible but non-distracting.

## Shapes
The shape language is **Rounded**, utilizing a 0.5rem (8px) corner radius as the standard. This softens the technical nature of the application, making it feel more approachable and user-friendly for both medical staff and patients.

- **Standard Elements (Buttons, Inputs):** 8px radius.
- **Large Containers (Cards, Modals):** 16px radius (`rounded-lg`).
- **Data Points (Tags, Chips):** Fully rounded/Pill-shaped to distinguish them from actionable buttons.

## Components
- **Buttons:** Primary buttons use Vital Green with white text. Secondary buttons use Clinical Blue with a ghost variant (Clinical Blue border and text) for less critical actions.
- **Input Fields:** Use White backgrounds with a Medical Dark (15% opacity) border. On focus, the border transitions to Clinical Blue with a 2px stroke.
- **Chips:** Used for patient status or categories. Use light tints (10% opacity) of the category color (e.g., Green for "Stable", Red for "Critical") with bold text in the same hue.
- **Cards:** White surfaces, 16px padding, 8px radius. Use a top-border accent (2px) in Clinical Blue to denote active selection or category.
- **Lists:** High-density rows with 1px Medical Dark (8% opacity) dividers. Alternate row colors are not permitted; use white space to separate line items instead.
- **Vital Sign Monitors:** Specific components that use Bio Purple for waveforms and high-contrast Emergency Red for "Out of Range" values.