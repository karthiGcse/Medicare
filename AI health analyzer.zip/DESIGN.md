---
name: Elite AI Clinical System
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#434657'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#747688'
  outline-variant: '#c4c5da'
  surface-tint: '#0046fa'
  primary: '#0035c5'
  on-primary: '#ffffff'
  primary-container: '#0047ff'
  on-primary-container: '#d4d9ff'
  inverse-primary: '#b9c3ff'
  secondary: '#006875'
  on-secondary: '#ffffff'
  secondary-container: '#00e3fd'
  on-secondary-container: '#00616d'
  tertiary: '#5c00ca'
  on-tertiary: '#ffffff'
  tertiary-container: '#7531e6'
  on-tertiary-container: '#e4d4ff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dde1ff'
  primary-fixed-dim: '#b9c3ff'
  on-primary-fixed: '#001257'
  on-primary-fixed-variant: '#0033c0'
  secondary-fixed: '#9cf0ff'
  secondary-fixed-dim: '#00daf3'
  on-secondary-fixed: '#001f24'
  on-secondary-fixed-variant: '#004f58'
  tertiary-fixed: '#eaddff'
  tertiary-fixed-dim: '#d2bbff'
  on-tertiary-fixed: '#25005a'
  on-tertiary-fixed-variant: '#5a00c6'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  display-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: '1.3'
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: '1.3'
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '500'
    lineHeight: '1.6'
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.6'
  label-caps:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '700'
    lineHeight: '1'
    letterSpacing: 0.08em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '600'
    lineHeight: '1'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 48px
  container-margin: 32px
  gutter: 16px
---

## Brand & Style

The design system is engineered for elite medical environments where AI precision meets human-centric care. The aesthetic is **Ultra-Premium Glassmorphism**, characterized by a luminous, sterile, yet inviting interface. It avoids the coldness of traditional clinical software by using high-fidelity mesh gradients and "active light" properties.

The personality is:
- **Pristine:** Every pixel feels sanitized and intentional.
- **Cognitive:** Designed for high-density information display without overwhelming the practitioner.
- **Luminous:** Utilizing light as a primary navigator through glow effects and translucent layering.
- **Reliable:** Balancing futuristic glass effects with the grounded stability of modern clinical standards.

The visual style merges **Glassmorphism** with **Corporate Modern** sensibilities, utilizing backdrop blurs to create a sense of physical depth and "living" data surfaces.

## Colors

The palette is anchored by **Sapphire Blue** (#0047FF) for authority and **Clinical Cyan** (#00E5FF) for interactive vitality.

- **Primary (Sapphire):** Used for core branding, primary actions, and critical data points.
- **Secondary (Clinical Cyan):** Used for "living" elements—AI-driven suggestions, active states, and successful clinical statuses.
- **Surface Strategy:** We utilize a "Luminous White" base. Glass containers use a 70% opacity white with a 20px backdrop blur to maintain legibility over mesh gradients.
- **Accents:** A subtle **Deep Violet** is reserved for complex diagnostic insights and specialized AI classifications.
- **Functional Colors:** Error states utilize a high-vibrancy "Pulse Red," while warnings use a "Caution Amber" that glows against the glass surfaces.

## Typography

**Plus Jakarta Sans** is the sole typeface for this design system, chosen for its modern geometry and exceptional legibility in data-dense clinical environments. 

The type hierarchy is strictly enforced to ensure clarity:
- **Display and Headlines:** Feature tighter letter-spacing and heavier weights to command attention on high-resolution displays.
- **Body Text:** Uses a Medium (500) weight as the default for readability against semi-transparent backgrounds.
- **Labels:** Utilizes all-caps for metadata and system status to distinguish static information from dynamic patient data.
- **Anti-Aliasing:** All text must be rendered with `grayscale` or `antialiased` smoothing to preserve the "high-fidelity" aesthetic.

## Layout & Spacing

This design system employs a **Fluid Grid** model optimized for high-density information. The core rhythm is based on a **4px baseline**, ensuring all components align with mathematical precision.

- **Desktop Layout:** A 12-column grid with a maximum content width of 1600px. Gutters are kept tight (16px) to maximize the "Data Dashboard" feel.
- **High-Density Reflow:** On large clinical monitors, the system expands to show multi-pane views (Patient History | Active Vitals | AI Analysis).
- **Mobile/Tablet:** Transitions to a 4/8 column grid respectively, with margins increasing to 24px for touch safety.
- **Layering:** Content is organized in "Slabs"—vertical sections separated by generous `xl` (48px) spacing to prevent visual fatigue.

## Elevation & Depth

Visual hierarchy is achieved through **Tonal Translucency** rather than traditional drop shadows.

- **The Glass Stack:**
  - **Level 0 (Background):** Subtle mesh gradients in Sapphire and Cyan.
  - **Level 1 (Main Surfaces):** `surface_glass` with 20px blur and a 1px solid white border (10% opacity).
  - **Level 2 (Popovers/Modals):** Increased blur (40px) and a subtle outer glow using the Primary Sapphire color at 5% opacity.
- **Glow states:** Interactive elements "ignite" when hovered. Instead of moving upwards (Y-axis), they increase in internal luminosity and outer border brightness.
- **Borders:** Every card and container must have a 1px "Inner Light" border to simulate the edge of a glass pane.

## Shapes

The shape language is **Modern Rounded**, conveying a sense of safety and approachability.

- **Standard Containers:** Use `rounded-md` (0.5rem) to maintain a professional, structured look.
- **Interactive Elements:** Buttons and Chips utilize `rounded-lg` (1rem) to differentiate them as touchable objects.
- **Inner Elements:** When nesting elements inside a card, the inner roundedness should be 4px smaller than the outer container to maintain visual harmony.

## Components

### Buttons
- **Primary:** Solid Sapphire background with a Clinical Cyan "inner glow" on hover.
- **Secondary/Glass:** Translucent background (20% white) with a 1px solid border. Text color is Sapphire.
- **AI Action:** A special button state featuring a subtle animated mesh gradient border.

### Chips & Tags
- Used for patient status (e.g., "Stable," "Critical").
- Backgrounds are 10% opacity of the status color (Cyan for stable, Red for critical) with a matching solid 1px border.

### Input Fields
- Understated glass panels. On focus, the 1px border transitions from soft grey to Clinical Cyan with a subtle outer neon glow.

### Cards
- The workhorse of the clinical system. Must use `surface_glass` styling. Headers within cards should have a subtle bottom separator (1px white at 5% opacity).

### Interactive Glowing Elements
- **Data Points:** In charts, active nodes should pulse with a Sapphire glow.
- **AI Insights:** Any information generated by the AI is flagged with a vertical "Clinical Cyan" bar on the left and a faint background glow to signify its origin.