---
name: Aura Health
colors:
  surface: '#f7f9fc'
  surface-dim: '#d8dadd'
  surface-bright: '#f7f9fc'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f7'
  surface-container: '#eceef1'
  surface-container-high: '#e6e8eb'
  surface-container-highest: '#e0e3e6'
  on-surface: '#191c1e'
  on-surface-variant: '#4c4354'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f4'
  outline: '#7e7386'
  outline-variant: '#cfc2d7'
  surface-tint: '#8422dc'
  primary: '#6e00c1'
  on-primary: '#ffffff'
  primary-container: '#8a2be2'
  on-primary-container: '#eed9ff'
  inverse-primary: '#dcb8ff'
  secondary: '#595f65'
  on-secondary: '#ffffff'
  secondary-container: '#dee3ea'
  on-secondary-container: '#5f656b'
  tertiary: '#713f00'
  on-tertiary: '#ffffff'
  tertiary-container: '#935400'
  on-tertiary-container: '#ffdaba'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#efdbff'
  primary-fixed-dim: '#dcb8ff'
  on-primary-fixed: '#2c0051'
  on-primary-fixed-variant: '#6700b5'
  secondary-fixed: '#dee3ea'
  secondary-fixed-dim: '#c2c7ce'
  on-secondary-fixed: '#171c21'
  on-secondary-fixed-variant: '#42474d'
  tertiary-fixed: '#ffdcbf'
  tertiary-fixed-dim: '#ffb873'
  on-tertiary-fixed: '#2d1600'
  on-tertiary-fixed-variant: '#6a3b00'
  background: '#f7f9fc'
  on-background: '#191c1e'
  surface-variant: '#e0e3e6'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  unit: 8px
  container-padding-mobile: 20px
  container-padding-desktop: 40px
  gutter: 24px
  stack-sm: 12px
  stack-md: 24px
  stack-lg: 48px
---

## Brand & Style
The design system is centered on a "Soft-Touch" philosophy for premium healthcare, prioritizing a sense of physical comfort and technological sophistication. By utilizing Neumorphism (Soft UI), the interface mimics the organic contours of modern medical devices and high-end wellness hardware.

The aesthetic is characterized by:
- **Tactile Comfort:** Surfaces that feel soft and physically responsive, reducing the "digital friction" often associated with medical data.
- **Airy Minimalism:** High levels of whitespace and a restricted color palette to instill a sense of calm and mental clarity for the patient.
- **Modern Precision:** Balancing the soft, extruded shapes with razor-sharp typography and vibrant accents to ensure the UI feels medically reliable and cutting-edge.

## Colors
The color strategy relies on a monochromatic base with a singular, high-energy accent. The background (#F0F2F5) acts as the "canvas" from which all elements are sculpted.

- **Primary (Elegant Purple):** Used exclusively for high-intent actions, progress indicators, and critical health metrics. 
- **The Sculpting Neutrals:** Success depends on the interplay between the background, the light shadow (#FFFFFF), and the dark shadow (#D1D9E6). These create the 3D extrusion effect.
- **Semantic Colors:** Use soft greens and ambers for secondary health statuses, but always maintain low saturation to avoid breaking the serene atmosphere.

## Typography
This design system utilizes **Plus Jakarta Sans** across all levels to maintain a cohesive, modern, and friendly tone. 

- **Weight Strategy:** Headlines use Semi-Bold and Bold weights to anchor the layout, as the neomorphic containers have low edge-contrast.
- **Readability:** Body text should maintain a high contrast ratio against the light gray background (use a deep charcoal, not pure black).
- **Scale:** On mobile devices, headline sizes should scale down aggressively to ensure medical data visualization remains the focal point.

## Layout & Spacing
The layout follows a fluid, breathable model with generous inner paddings to support the large corner radii of neomorphic cards.

- **Soft Grid:** Avoid tight packing. Elements need "air" around them for the dual shadows to render effectively without overlapping.
- **Vertical Rhythm:** Use a 48px or 64px vertical stack between major card sections to emphasize the "objects floating in space" feel.
- **Margins:** Maintain a minimum 20px safe area on mobile to prevent cards from feeling cramped against the screen edge.

## Elevation & Depth
Depth is the core differentiator of this design system. Instead of standard Z-axis shadows, we use the Neomorphic Dual-Shadow technique.

- **Extruded (Raised):** Used for cards and buttons. Apply a top-left shadow of white (#FFFFFF) and a bottom-right shadow of soft blue-gray (#D1D9E6). Use a blur radius between 12px and 20px for a soft look.
- **Inset (Sunken):** Used for input fields and active button states. The shadows are reversed and placed inside the element's frame to create a "pressed into the surface" effect.
- **Intensity:** Shadows should be subtle. High-contrast shadows ruin the medical "cleanliness" of the UI.

## Shapes
Shapes are exceptionally round and organic, mimicking human-centric design.

- **Large Surfaces:** Main cards and containers must use a radius between 24px and 32px.
- **Standard Elements:** Buttons and input fields should utilize a "Pill" shape (fully rounded) to maximize the tactile, soft-UI aesthetic.
- **Consistency:** Never mix sharp corners with neomorphic shadows; the shadows require curved edges to appear natural and "molded."

## Components
- **Cards:** The primary container. No borders. Use the Extruded shadow style. Background color must match the page background (#F0F2F5).
- **Buttons (Primary):** Pill-shaped. Use the Elegant Purple background with a white label. Apply a purple-tinted neomorphic shadow to make it "glow" slightly.
- **Buttons (Secondary/Ghost):** Pill-shaped. Background matches page. Use Extruded shadow.
- **Input Fields:** Inset (sunken) shape. Ensure the internal padding is large enough (16px+) to accommodate the inner shadows without crowding the text.
- **Chips:** Small, pill-shaped extruded elements. Use for health tags or filter categories.
- **Progress Rings:** Use a thick stroke with rounded caps. The track should be "Inset" while the active progress (Purple) should appear to sit on top or "glow."
- **Selection Controls:** Radio buttons and checkboxes should appear as small inset circles/squares that become extruded or "filled" when active.