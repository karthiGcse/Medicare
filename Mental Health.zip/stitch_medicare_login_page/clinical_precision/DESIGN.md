---
name: Clinical Precision
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#424752'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#727784'
  outline-variant: '#c2c6d4'
  surface-tint: '#115cb9'
  primary: '#003f87'
  on-primary: '#ffffff'
  primary-container: '#0056b3'
  on-primary-container: '#bbd0ff'
  inverse-primary: '#acc7ff'
  secondary: '#bc000a'
  on-secondary: '#ffffff'
  secondary-container: '#e2241f'
  on-secondary-container: '#fffbff'
  tertiary: '#722b00'
  on-tertiary: '#ffffff'
  tertiary-container: '#983c00'
  on-tertiary-container: '#ffc2a7'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d7e2ff'
  primary-fixed-dim: '#acc7ff'
  on-primary-fixed: '#001a40'
  on-primary-fixed-variant: '#004491'
  secondary-fixed: '#ffdad5'
  secondary-fixed-dim: '#ffb4aa'
  on-secondary-fixed: '#410001'
  on-secondary-fixed-variant: '#930005'
  tertiary-fixed: '#ffdbcc'
  tertiary-fixed-dim: '#ffb694'
  on-tertiary-fixed: '#351000'
  on-tertiary-fixed-variant: '#7b2f00'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Atkinson Hyperlegible Next
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Atkinson Hyperlegible Next
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  container-padding-mobile: 16px
  container-padding-desktop: 40px
  gutter: 24px
  stack-sm: 12px
  stack-md: 24px
  stack-lg: 48px
---

## Brand & Style
The design system is anchored in trust, reliability, and clinical excellence. It targets patients and healthcare providers who require a high-stakes interface that remains calm under pressure. The aesthetic is **Corporate Modern** with a lean toward **Minimalism**, prioritizing clarity of information over decorative elements.

The emotional response should be one of "secure competence." By utilizing generous whitespace and a restricted, purposeful color palette, the UI reduces cognitive load, making complex medical data feel manageable and safe. The design style relies on high-quality typography and subtle depth to guide the user's eye toward critical actions and health metrics.

## Colors
The palette is dominated by **Medical Blue**, a shade synonymous with authority and hygiene in the healthcare sector. This is supported by a pristine white foundation to maintain a "sterile" yet welcoming environment.

The **Vibrant Red** is reserved specifically for the "C" in the brand mark and critical health alerts (e.g., heart rate warnings, emergency buttons). This creates a high-contrast focal point that signals urgency or brand identity without overwhelming the professional blue-and-white harmony. 

- **Primary**: Used for headers, primary actions, and active states.
- **Accent (Red)**: Used for brand identity and critical system-level alerts.
- **Neutral**: A range of slate grays for secondary text and subtle borders to keep the interface grounded.

## Typography
The typography strategy prioritizes legibility across all age groups. **Plus Jakarta Sans** provides a modern, soft touch for headlines, preventing the app from feeling too institutional. **Inter** handles high-density data and body text with systematic precision.

Crucially, **Atkinson Hyperlegible Next** is used for all labels, captions, and data points. This font is specifically designed for low-vision readers, ensuring that dosages, time-stamps, and numerical health data are unmistakable. Line heights are kept generous to prevent text "crowding," which is essential in a medical context.

## Layout & Spacing
This design system utilizes a **Fixed Grid** for desktop (12 columns, 1200px max-width) and a **Fluid Grid** for mobile (4 columns). The rhythm is based on an 8px baseline to ensure mathematical consistency.

Layouts should favor "The Power of Empty Space." Content is grouped into logical modules with wide margins (48px+) between major sections to prevent user anxiety. On mobile, cards should extend to the edge of the screen minus the 16px container padding to maximize the touch target area for clinical data entries.

## Elevation & Depth
Hierarchy is established through **Ambient Shadows** and **Tonal Layers**. We avoid heavy black shadows in favor of soft, diffused blurs tinted with the primary blue (#0056B3 at 5-10% opacity).

1.  **Level 0 (Base)**: White background.
2.  **Level 1 (Cards/Surface)**: Subtle 1px border (#E2E8F0) with a very soft shadow (0px 4px 12px rgba(0, 86, 179, 0.05)).
3.  **Level 2 (Modals/Overlays)**: Higher elevation shadow (0px 12px 32px rgba(0, 86, 179, 0.12)) to indicate temporary interaction.

This creates a sense of "layered paper," where the most important information physically sits closer to the user.

## Shapes
The shape language uses **Rounded** corners (8px base). This choice is intentional: sharp corners feel aggressive and "medical-cold," while fully pill-shaped elements can feel too casual or "bubbly." 

Medium roundedness strikes the balance of a modern, high-tech tool that remains approachable and human-centric. Large components like health summary cards or hero banners should utilize `rounded-xl` (24px) to soften the interface.

## Components

- **Buttons**: Primary buttons are solid Medical Blue with white text. Secondary buttons use a Medical Blue outline. Critical actions (e.g., "Cancel Appointment" or "Emergency SOS") use the Vibrant Red accent.
- **Cards**: Use white backgrounds with Level 1 elevation. Cards should have a 16px internal padding. Title text within cards should always be Plus Jakarta Sans Bold.
- **Input Fields**: Focus states are indicated by a 2px Medical Blue border and a soft blue glow. Error states use the Vibrant Red.
- **Chips/Status Badges**: Used for appointment statuses (e.g., "Confirmed", "Pending"). These use low-saturation background tints of the status color (e.g., soft green for confirmed) with high-contrast text.
- **Lists**: Medical history or medication lists must use the Atkinson Hyperlegible Next font for all dosage details to ensure zero ambiguity.
- **Progress Indicators**: Circular health rings (e.g., activity or treatment completion) should use Medical Blue, with a light gray track.