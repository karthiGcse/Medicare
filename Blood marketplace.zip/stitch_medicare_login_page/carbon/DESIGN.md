---
name: Clinical Precision
colors:
  surface: '#fbf9f8'
  surface-dim: '#dbd9d9'
  surface-bright: '#fbf9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3f3'
  surface-container: '#f4f4f4'
  surface-container-high: '#eae8e7'
  surface-container-highest: '#e4e2e2'
  on-surface: '#1b1c1c'
  on-surface-variant: '#5b3f44'
  inverse-surface: '#303030'
  inverse-on-surface: '#f2f0f0'
  outline: '#8f6f74'
  outline-variant: '#e4bdc3'
  surface-tint: '#bc0051'
  primary: '#b7004f'
  on-primary: '#ffffff'
  primary-container: '#e40a65'
  on-primary-container: '#fffbff'
  inverse-primary: '#ffb1c0'
  secondary: '#5f5e5e'
  on-secondary: '#ffffff'
  secondary-container: '#e2dfde'
  on-secondary-container: '#636262'
  tertiary: '#006952'
  on-tertiary: '#ffffff'
  tertiary-container: '#008469'
  on-tertiary-container: '#f5fff9'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffd9df'
  primary-fixed-dim: '#ffb1c0'
  on-primary-fixed: '#3f0017'
  on-primary-fixed-variant: '#90003d'
  secondary-fixed: '#e5e2e1'
  secondary-fixed-dim: '#c8c6c5'
  on-secondary-fixed: '#1c1b1b'
  on-secondary-fixed-variant: '#474746'
  tertiary-fixed: '#58fccf'
  tertiary-fixed-dim: '#2ddfb4'
  on-tertiary-fixed: '#002118'
  on-tertiary-fixed-variant: '#00513f'
  background: '#fbf9f8'
  on-background: '#1b1c1c'
  surface-variant: '#e4e2e2'
  background-subtle: '#f8f9fa'
  outline-soft: '#e0e0e0'
  error-red: '#da1e28'
  urgent-glow: rgba(255, 45, 120, 0.1)
typography:
  display-xl:
    fontFamily: Sora
    fontSize: 36px
    fontWeight: '900'
    lineHeight: '1.1'
    letterSpacing: -0.05em
  headline-lg:
    fontFamily: Sora
    fontSize: 24px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-sm:
    fontFamily: Sora
    fontSize: 18px
    fontWeight: '700'
    lineHeight: '1.4'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '500'
    lineHeight: '1.5'
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
  label-caps:
    fontFamily: Space Grotesk
    fontSize: 12px
    fontWeight: '700'
    lineHeight: '1'
    letterSpacing: 0.15em
  label-micro:
    fontFamily: Space Grotesk
    fontSize: 10px
    fontWeight: '700'
    lineHeight: '1'
    letterSpacing: 0.2em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  container-max: 1280px
  gutter: 24px
  margin-mobile: 16px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 32px
  section-gap: 48px
---

## Brand & Style
The brand identity is "Clinical Precision"—a fusion of high-stakes medical urgency and sophisticated technical reliability. It targets medical professionals and logistics coordinators who require immediate clarity and trust. 

The visual style is **Corporate Modern with a "Cyber-Clinical" edge**. It utilizes a pristine, laboratory-white base layered with high-energy "Pulse Pink" and "Vital Teal" accents. The aesthetic is defined by extreme legibility, technical data overlays (like scan lines and grid patterns), and a rigorous information hierarchy that mimics medical instrumentation while maintaining a high-end, contemporary SaaS feel.

## Colors
The palette is dominated by **Pulse Pink (#ff2d78)**, used strategically for critical actions, blood-type identifiers, and branding. This is balanced by **Vital Teal (#00d1a7)**, representing safety, certification, and system health.

Neutral tones move from a deep **Carbon Black (#161616)** for primary text to a series of cool grays for structural elements. The background uses a subtle off-white **(#f8f9fa)** with a delicate 40px grid overlay to reinforce the "technical blueprint" aesthetic. Interactive surfaces should maintain high contrast to ensure readability under high-stress clinical environments.

## Typography
The typographic system uses a three-tier font strategy to separate concerns:
- **Sora (Display/Headline):** High-personality, geometric, and bold. Used for branding, blood types, and major section titles.
- **Inter (Body):** Maximum legibility for data points, descriptions, and UI controls.
- **Space Grotesk (Labels/Technical):** A monospaced-adjacent feel used for "metadata" (Unit Refs, timestamps, status tags) to evoke a sense of machine-readability.

Scale is used aggressively; critical data like blood types are oversized and heavy, while supporting labels are tiny but tracked out for clarity.

## Layout & Spacing
The system utilizes a **Fixed Grid** approach for large screens, centering content within a 1280px max-width container. 

- **Grid:** A 12-column system on desktop, collapsing to 1 column on mobile. 
- **Bento Logic:** Complex information is grouped into "Bento" cards of varying spans (e.g., 1/3 or 2/3 width) to create a visual hierarchy of importance.
- **Rhythm:** Vertical spacing follows an 8px base unit. Section headers are preceded by a 4px solid vertical accent bar in tertiary colors to anchor the eye.

## Elevation & Depth
Depth is achieved through **Clinical Shadows** and **Tonal Layering** rather than traditional elevation.

- **Standard Elevation:** Elements use a very soft, multi-layered shadow (`0 4px 6px -1px rgba(0, 0, 0, 0.05)`) to lift slightly off the background.
- **High Elevation:** Interactive or featured cards use an expanded shadow on hover to simulate physical proximity.
- **Layering:** Surfaces use `#ffffff` (White), while secondary containers (like internal info blocks) use `#f4f4f4` (Light Gray) with a subtle `#e0e0e0` border to create "sunken" or "embedded" areas without using shadows.
- **Glassmorphism:** The Top App Bar uses a `90%` white opacity with a `20px` backdrop blur to maintain context while scrolling.

## Shapes
The shape language is "Calculated Softness." While the system is technical, it avoids sharp 0px corners to remain approachable.

- **Primary Containers:** 1rem (16px) corner radius for main cards.
- **Inputs & Search Bars:** 0.75rem (12px) for a modern, fluid feel.
- **Interactive Tags/Sort Buttons:** 0.25rem (4px) or completely sharp to denote they are smaller, functional utilities.
- **Buttons:** 0.75rem (12px) to match the input fields, ensuring a cohesive "row" aesthetic in search blocks.

## Components
- **Buttons:** Primary buttons are solid `primary-color` with white text, bold caps. Secondary buttons use a white fill with an `outline-soft` border. Always include a subtle scale-down effect (`active:scale-95`) on click.
- **Cards:** White background, `outline-soft` border, and "Clinical Shadow." On hover, cards should translate -4px on the Y-axis.
- **Data Tags:** Small, high-contrast pills. Use `primary` for "Urgent" and `tertiary` for "Certified/Safe."
- **Progress Bars:** Ultra-thin (6px) tracks using `surface-container` with solid `primary` or `tertiary` fills to indicate supply levels.
- **Inputs:** Large, borderless text entry within a shadowed container. Use `placeholder-opacity-20` for secondary guidance.
- **Icons:** Use "Material Symbols Outlined" with a consistent 400 weight. Icons should be tinted `primary` for search/actions and `on-surface-variant` for purely informational metadata.