---
name: Vibrant Interconnect
colors:
  surface: '#fff7ff'
  surface-dim: '#ead0ff'
  surface-bright: '#fff7ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fbf0ff'
  surface-container: '#f7e9ff'
  surface-container-high: '#f3e2ff'
  surface-container-highest: '#f0dbff'
  on-surface: '#2c0051'
  on-surface-variant: '#554051'
  inverse-surface: '#480081'
  inverse-on-surface: '#f9ecff'
  outline: '#887082'
  outline-variant: '#dabed3'
  surface-tint: '#8b418f'
  primary: '#883f8c'
  on-primary: '#ffffff'
  primary-container: '#a458a7'
  on-primary-container: '#fffbff'
  inverse-primary: '#ffa9fe'
  secondary: '#9a3097'
  on-secondary: '#ffffff'
  secondary-container: '#fe88f3'
  on-secondary-container: '#7c0d7b'
  tertiary: '#00666e'
  on-tertiary: '#ffffff'
  tertiary-container: '#00818a'
  on-tertiary-container: '#f5feff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffd6fa'
  primary-fixed-dim: '#ffa9fe'
  on-primary-fixed: '#36003c'
  on-primary-fixed-variant: '#702875'
  secondary-fixed: '#ffd7f5'
  secondary-fixed-dim: '#ffabf3'
  on-secondary-fixed: '#380038'
  on-secondary-fixed-variant: '#7e0f7d'
  tertiary-fixed: '#82f3ff'
  tertiary-fixed-dim: '#64d7e2'
  on-tertiary-fixed: '#002022'
  on-tertiary-fixed-variant: '#004f55'
  background: '#fff7ff'
  on-background: '#2c0051'
  surface-variant: '#f0dbff'
typography:
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 16px
  lg: 24px
  xl: 32px
  gutter: 16px
  margin: 24px
---

# Vibrant Interconnect Design System

## Brand & Style
Vibrant Interconnect is a design system that blends high-energy digital aesthetics with modern professional clarity. The brand personality is expressive, tech-forward, and energetic, aimed at audiences who value both speed and a distinct visual identity.

The style is a hybrid of **High-Contrast / Bold** and **Corporate Modern**. It uses a striking magenta and deep purple palette to create a memorable digital presence, while maintaining the structural integrity and readability of a professional interface. The goal is to evoke a sense of innovation and creative energy without sacrificing usability.

## Colors
The color palette is dominated by a high-fidelity magenta and purple spectrum. The **primary color (#e894e8)** is a light, vibrant orchid that serves as the main brand identifier for key actions and highlights. The **tertiary color (#32afba)**, a cool teal, provides a sharp functional contrast, ideal for secondary call-outs or informational status indicators. 

The **neutral palette (#9c58e2)** is derived from a deep violet, ensuring that even the most "boring" parts of the interface—like borders, shadows, and secondary text—carry a hint of the brand's energetic DNA. This light-mode system relies on white surfaces with tinted neutral accents to maintain a clean yet colorful environment.

## Typography
The system utilizes **Inter** for all typographic layers, providing a highly legible, geometric foundation that complements the bold color choices. 

- **Headlines:** Set in Inter with tight tracking and bold weights to ground the interface.
- **Body:** Uses Inter’s standard weight for maximum readability in dense information environments.
- **Labels:** Medium weights are used for UI metadata, buttons, and navigation items to ensure they stand out against vibrant backgrounds.

The scale is designed to be responsive, with large headlines stepping down gracefully for mobile viewports to maintain vertical rhythm.

## Layout & Spacing
The layout follows a **fluid grid** model with a base 8px spatial rhythm. This ensures consistency across all components and page structures.

- **Grid:** A 12-column grid for desktop, 8-column for tablet, and 4-column for mobile.
- **Margins & Gutters:** Standardized at 24px margins and 16px gutters to provide enough white space to balance the high-intensity color palette.
- **Rhythm:** Vertical spacing should strictly adhere to multiples of 4px and 8px to maintain a clean, organized aesthetic even with the bold visual style.

## Elevation & Depth
Depth is conveyed through **tonal layers** and soft, tinted shadows. Rather than using neutral greys for shadows, this system uses low-opacity versions of the neutral violet (#9c58e2) to create "ambient depth" that feels integrated with the color palette.

Surface levels are defined by slight shifts in saturation and brightness, with active elements appearing to "lift" through the use of soft, diffused shadows that borrow from the primary color's hue.

## Shapes
The shape language is defined by **Pill-shaped (Level 3)** roundedness. This extreme rounding softens the high-contrast colors, making the interface feel friendly and approachable despite its bold palette.

- **Small Components:** Buttons and chips use a full-radius pill shape.
- **Large Containers:** Cards and modals use a 2rem (32px) corner radius to maintain a consistent "squishy" and modern feel.

## Components
- **Buttons:** Primary buttons are pill-shaped, using the primary orchid color with white text. They should have a subtle glow effect on hover using the primary tint.
- **Inputs:** Use high-contrast borders (1px) in the neutral violet, with a 1rem radius. Focus states switch to the tertiary teal for clear functional feedback.
- **Cards:** Elevated with soft violet-tinted shadows and a 2rem corner radius. Backgrounds should be pure white to allow the colors to pop.
- **Chips:** Highly rounded, using light tints of the primary or tertiary colors with darker text for categorizing and filtering.