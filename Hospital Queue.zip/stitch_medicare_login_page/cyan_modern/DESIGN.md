---
name: Cyan Modern
colors:
  surface: '#f4fafd'
  surface-dim: '#d4dbdd'
  surface-bright: '#f4fafd'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eef5f7'
  surface-container: '#e8eff1'
  surface-container-high: '#e3e9eb'
  surface-container-highest: '#dde4e6'
  on-surface: '#161d1e'
  on-surface-variant: '#3c494c'
  inverse-surface: '#2b3233'
  inverse-on-surface: '#ebf2f4'
  outline: '#6c797c'
  outline-variant: '#bbc9cc'
  surface-tint: '#006875'
  primary: '#006875'
  on-primary: '#ffffff'
  primary-container: '#0fcce4'
  on-primary-container: '#00525d'
  inverse-primary: '#32d9f1'
  secondary: '#35656f'
  on-secondary: '#ffffff'
  secondary-container: '#b9ebf6'
  on-secondary-container: '#3b6b75'
  tertiary: '#8b5000'
  on-tertiary: '#ffffff'
  tertiary-container: '#ffa643'
  on-tertiary-container: '#6e3f00'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#9eefff'
  primary-fixed-dim: '#32d9f1'
  on-primary-fixed: '#001f24'
  on-primary-fixed-variant: '#004e59'
  secondary-fixed: '#b9ebf6'
  secondary-fixed-dim: '#9ecfda'
  on-secondary-fixed: '#001f25'
  on-secondary-fixed-variant: '#194d57'
  tertiary-fixed: '#ffdcbe'
  tertiary-fixed-dim: '#ffb870'
  on-tertiary-fixed: '#2c1600'
  on-tertiary-fixed-variant: '#693c00'
  background: '#f4fafd'
  on-background: '#161d1e'
  surface-variant: '#dde4e6'
typography:
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  gutter: 16px
  margin: 24px
---

# Design System: Cyan Modern

## Brand & Style
The brand identity has shifted from a warm, earthen orange palette to a vibrant, tech-forward, and energetic aesthetic. The personality is professional yet highly modern, leaning into a "Corporate / Modern" style with a refreshing digital clarity. It evokes a sense of innovation, precision, and approachability. The goal is to provide a clean, high-performance interface that feels both reliable and cutting-edge.

## Colors
The color palette is anchored by a vibrant Cyan primary (`#09cbe3`), which serves as the main driver for action and brand recognition. This is complemented by a sophisticated Muted Teal secondary (`#4e7e88`) for supporting elements and a Soft Amber tertiary (`#ffa643`) to provide high-contrast accents and highlight critical information. The neutral palette is a balanced Slate Gray (`#71787a`), ensuring that the vibrant primary tones remain the focal point while maintaining excellent readability and a clean UI structure.

## Typography
The system utilizes **Inter** across all typographic roles to achieve maximum legibility and a contemporary, "app-first" feel. This transition away from Public Sans emphasizes a more streamlined, geometric efficiency. Headlines are bold and clear to establish strong hierarchy, while body text is optimized for readability with generous line heights. Labels use a medium weight to ensure functional elements remain distinct and scanable.

## Layout & Spacing
The layout follows a fluid 8px grid system. This ensures consistency across all components and spacing. Margins and gutters are set to provide ample breathing room, maintaining the clean, modern aesthetic. On mobile, margins reduce to 16px, while desktop layouts leverage a 12-column grid to organize complex data and content structures efficiently.

## Elevation & Depth
Depth is communicated through tonal layering and soft ambient shadows. Surfaces use subtle shifts in the neutral and secondary palettes to indicate hierarchy. Primary actions may feature a slight lift with a cyan-tinted shadow to reinforce their importance, while cards and containers use low-opacity, diffused shadows to appear integrated into the background rather than floating high above it.

## Shapes
The design language has moved from sharp, square corners to a highly approachable **Pill-shaped** roundedness. Standard components like buttons and inputs feature a 1rem (16px) corner radius, while larger containers like cards use 2rem (32px). This high degree of rounding softens the technical feel of the cyan palette, making the interface feel friendly and ergonomic.

## Components
- **Buttons:** Fully rounded (pill-style) with a solid Cyan fill for primary actions. Text is high-contrast white.
- **Inputs:** Soft, rounded borders using the neutral palette, with a Cyan focus ring to indicate activity.
- **Cards:** Large corner radii (32px) with subtle shadows or light gray borders to define boundaries without adding visual clutter.
- **Chips & Tags:** Small, pill-shaped elements using the secondary teal or tertiary amber for categorization and status.
- **Checkboxes:** Rounded corners to match the overall shape language, using the primary cyan for the checked state.